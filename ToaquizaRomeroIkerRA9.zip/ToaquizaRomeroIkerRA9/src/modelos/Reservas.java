package modelos;

public class Reservas {
	private int codigo;
	private int precio = 10;
	private int entradas;
	private int sala;
	private String telefono;

	public Reservas(int sala, int entradas, String telefono) {
		super();
		this.entradas= entradas;
		this.sala = sala;
		this.telefono = telefono;
		this.precio= precio;
		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getPrecio() {
		int total = precio * entradas;
		return total;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public int getEntradas() {
		return entradas;
	}

	public void setEntradas(int entradas) {
		this.entradas = entradas;
	}

	public int getSala() {
		return sala;
	}

	public void setSala(int sala) {
		this.sala = sala;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

}
