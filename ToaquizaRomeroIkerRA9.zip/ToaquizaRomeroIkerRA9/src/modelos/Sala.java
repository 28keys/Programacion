package modelos;

public class Sala {

	private String pelicula;
	private int aforo;
	private int sala;
	private int plazas_ocupadas;

	public Sala(String pelicula, int aforo, int sala, int plazas_ocupadas) {
		super();
		this.pelicula = pelicula;
		this.aforo = aforo;
		this.sala = sala;
		this.plazas_ocupadas = plazas_ocupadas;
	}

	@Override
	public String toString() {
		return "Sala [pelicula=" + pelicula + ", aforo=" + aforo + ", sala=" + sala + ", plazas_ocupadas="
				+ plazas_ocupadas + "]";
	}

	public String getPelicula() {
		return pelicula;
	}

	public void setPelicula(String pelicula) {
		this.pelicula = pelicula;
	}

	public int getAforo() {
		return aforo;
	}

	public void setAforo(int aforo) {
		this.aforo = aforo;
	}

	public int getSala() {
		return sala;
	}

	public void setSala(int sala) {
		this.sala = sala;
	}

	public int getPlazas_ocupadas() {
		return plazas_ocupadas;
	}

	public void setPlazas_ocupadas(int plazas_ocupadas) {
		this.plazas_ocupadas = plazas_ocupadas;
	}


	
	
	
	
}
