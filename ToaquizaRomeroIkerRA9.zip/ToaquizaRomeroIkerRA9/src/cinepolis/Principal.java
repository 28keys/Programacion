package cinepolis;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.sql.*;

import bbdd.*;
import modelos.Reservas;
import modelos.Sala;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int opc = 0;

		BD_Cinepolis bd = new BD_Cinepolis("mysql-properties.xml");

		do {
			System.out.println("\n\nGESTIÓN CINEPOLIS");
			System.out.println("***************");
			System.out.println("1. Información de las salas");
			System.out.println("2. Alta reserva");
			System.out.print("\tTeclea opción: ");
			try {
				opc = sc.nextInt();
			}

			catch (InputMismatchException e) {
				System.out.println("Debes introducir número 1-5");
				opc = 0;
			}

			sc.nextLine();
			switch (opc) {
			case 1:
				ArrayList<Sala> salas;
				try {
					salas = bd.mostrarSalas();
					for (int i = 0; i < salas.size(); i++)
						System.out.println(salas.get(i).toString());
					System.out.println("Sobre que sala deseas calcular el aforo?");
					int sala = sc.nextInt();
					int plazas = bd.plazasLibres(sala);
					System.out.println("Plazas disponibles " + plazas);
				} catch (ErrorBaseDatos e) {
					System.out.println("Error, contacte son sistemas");
				}
				break;
			case 2:
				System.out.println("Anota sala");
				int sala = sc.nextInt();
				System.out.println("Anota numero de entradas");
				int numero = sc.nextInt();
				try {
					int entradas = bd.entradasDisponibles(sala);
					if (numero > entradas) {
						System.out.println("ERROR, no hay entradas suficientes");
						break;

					} else {
						System.out.println("Anota numero de telefono");
						sc.nextLine();
						String telefono = sc.nextLine();
						int filas = bd.altaReserva(new Reservas(sala, numero, telefono));
						switch (filas) {
						case 1:
							System.out.println("Tarjeta añadida correctamente");
							int añadir = bd.modificar_plazas_ocupadas(filas);
							break;
						case 0:
							System.out.println("No añadida, contacte con sistemas");
							break;
						}
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas");
				}

				break;
			}
			
		} while (opc != 3);
	}
}
