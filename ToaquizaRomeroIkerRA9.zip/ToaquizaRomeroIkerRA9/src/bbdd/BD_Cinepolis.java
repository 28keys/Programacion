package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;

import cinepolis.*;

import modelos.Reservas;
import modelos.Sala;

import java.time.*;

public class BD_Cinepolis extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	public BD_Cinepolis(String file) {
		super(file);
	}

	public ArrayList<Sala> mostrarSalas() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM salas";
		ArrayList<Sala> salas = new ArrayList<Sala>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				salas.add(new Sala(reg.getString("pelicula"), reg.getInt("aforo"), reg.getInt("sala"),
						reg.getInt("plazas_ocupadas")));

			}
			s.close();
			this.cerrar();
			return salas;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar alumno");
		}
	}

	public int plazasLibres(int sala) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT aforo FROM salas WHERE sala = " + sala;
		int numero = 0;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				numero = reg.getInt("aforo");
			}
			s.close();
			this.cerrar();
			return numero;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar alumno");

		}

	}

	public int entradasDisponibles(int numero) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT entradas FROM reservas WHERE sala = " + numero;
		int numeroEntradas = 0;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				numeroEntradas = reg.getInt("entradas");
			}
			s.close();
			this.cerrar();
			return numeroEntradas;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar entradas");

		}
	}

	public int altaReserva(Reservas re) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO reservas VALUES (" + re.getCodigo() + "," + re.getPrecio() + ","
				+ re.getEntradas() + "," + re.getSala() + ",'" + re.getTelefono() + "')";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("No se puede realizar el alta de la tarjeta");
		}
	}

	public int modificar_plazas_ocupadas(int filas) {
		String cadena = "UPDATE salas set plazas_ocupadas=" + 1;
		try {
			this.abrir();
			s = c.createStatement();
			int filaS = s.executeUpdate(cadena);
			s.close();
			this.cerrar();
			return filas;

		} catch (SQLException e) {
			this.cerrar();
			return -1;
		}

	}
}
