package modelos;

import java.time.LocalDate;
import java.util.ArrayList;

public class Movimiento {

	private int numero;
	private int tarjeta;
	private int cargado;
	private double importe;
	private LocalDate fecha;

	public Movimiento(int tarjeta, double importe) {
		super();
		this.numero = numero;
		this.tarjeta = tarjeta;
		this.cargado = 0;
		this.importe = importe;
		this.fecha = LocalDate.now();
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getTarjeta() {
		return tarjeta;
	}

	public void setTarjeta(int tarjeta) {
		this.tarjeta = tarjeta;
	}

	public int getCargado() {
		return cargado;
		
	}

	public void setCargado(int cargado) {
		this.cargado = cargado;
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	
	
}
