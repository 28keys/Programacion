package modelos;

import java.time.LocalDate;
import java.util.ArrayList;

public class Tarjeta {
	private int cuenta;
	private int numero;
	private String titular;
	private double limite;
	private String tipo;
	private LocalDate fechaCaducidad;
	private String clave;
	private int bloqueada;
	private double dineroASacar;
	
	// Buscar Tarjeta Debito y credito
	public Tarjeta(int numero, int cuenta ,String titular, double limite, String tipo, LocalDate fechaCaducidad,
			String clave, int bloqueada) {
		super();
		this.cuenta = cuenta;
		this.numero = numero;
		this.titular = titular;
		this.limite = limite;
		this.tipo = tipo;
		this.fechaCaducidad = fechaCaducidad;
		this.clave = clave;
		this.bloqueada = 0;
	}

	// Alta Tarjeta de credito
	public Tarjeta(int numero, int cuenta, String titular, double limite, String clave) {
		super();
		this.titular = titular;
		this.cuenta = cuenta;
		this.numero = numero;
		this.limite = limite;
		tipo = "C";
		this.fechaCaducidad = LocalDate.now().plusYears(1); /*La fecha de caducidad de dicha tarjeta será la de
				un año después de la fecha actual.*/
		this.clave = clave;
		this.bloqueada = 0;
	}

	// Alta Tarjeta de debito
	public Tarjeta(int numero, int cuenta, String titular, String clave) {
		super();
		this.numero = numero;
		this.cuenta = cuenta;
		this.titular = titular;
		this.clave = clave;
		tipo = "D";
		fechaCaducidad = LocalDate.now().plusMonths(6); /*
														 * "La fecha de caducidad será de 6 meses después de la fecha actual."
														 */
		bloqueada = 0; /* "El límite es 0." */
	}

	public int getCuenta() {
		return cuenta;
	}

	public void setCuenta(int cuenta) {
		this.cuenta = cuenta;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		this.limite = limite;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public LocalDate getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(LocalDate fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public int getBloqueada() {
		return bloqueada;
	}

	public void setBloqueada(int bloqueada) {
		this.bloqueada = bloqueada;
	}

	public double getDineroASacar() {
		return dineroASacar;
	}

	public void setDineroASacar(double dineroASacar) {
		this.dineroASacar = dineroASacar;
	}

	
	

}
