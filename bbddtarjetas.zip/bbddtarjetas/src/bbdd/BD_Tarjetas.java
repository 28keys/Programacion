package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.*;
import colegio.*;
import modelos.Cuenta;
import modelos.Movimiento;
import modelos.Tarjeta;

public class BD_Tarjetas extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	public BD_Tarjetas(String file) {
		super(file);
	}

	public ArrayList<Cuenta> buscarCuentasPorTitular(String dni) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM cuentas WHERE titular1 ='" + dni + "' OR titular2 ='" + dni
				+ "' OR titular3 ='" + dni + "'";
		ArrayList<Cuenta> listaCuentas = new ArrayList<Cuenta>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				listaCuentas.add(new Cuenta(reg.getInt("número"), reg.getString("titular1"), reg.getString("titular2"),
						reg.getString("titular3"), reg.getDouble("saldo"), reg.getDate("fecha").toLocalDate()));
			}
			s.close();
			this.cerrar();
			return listaCuentas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se pudo listar las cuentas");

		}
	}

	public int añadir_tarjeta(Tarjeta tar) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO tarjetas VALUES(" + tar.getNumero() + "," + tar.getCuenta() + ",'"
				+ tar.getTitular() + "'," + tar.getLimite() + ",'" + tar.getTipo() + "','" + tar.getFechaCaducidad()
				+ "','" + tar.getClave() + "'," + tar.getBloqueada() + ")";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
			/*El error que tuve fue que en el constructor para dar de alta la tarjeta de credito, 
			 * como habia cambiado los nombres del numero de la tarjeta y el de la cuenta no lo habia
			 * cambiado en todos y tenia this.numero = numero, this.numero = numero, por eso al hacer
			 * insert solo pillaba el numero de tarjeta y el de cuenta se quedaba en 0*/
		}
	}

	public Cuenta buscarCuenta(int numCuenta) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM cuentas WHERE número='" + numCuenta + "'";
		Cuenta ct = null;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				ct = new Cuenta(reg.getInt("número"), reg.getString("titular1"), reg.getString("titular2"),
						reg.getString("titular3"), reg.getDouble("saldo"), reg.getDate("fecha").toLocalDate());
			}
			s.close();
			this.cerrar();
			return ct;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar cuenta");

		}
	}

	public int BuscarUltimoNumTarjeta() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT MAX(numero) from tarjetas"; /*
																 * "El número de tarjeta será uno más que el número más alto hasta el momento"
																 */
		int ultimo = 0;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				ultimo = reg.getInt(1);
			}
			s.close();
			this.cerrar();
			return ultimo;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar numero");
		}
	}

	public Tarjeta buscarTarjetaDebito(int numTarjeta, String clave) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM tarjetas WHERE numero=" + numTarjeta + " AND clave ='" + clave + "'";
		Tarjeta t = null;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				t = new Tarjeta(reg.getInt("numero"), reg.getInt("cuenta"), reg.getString("titular"),
						reg.getDouble("limite"), reg.getString("tipo"), reg.getDate("caducidad").toLocalDate(),
						reg.getString("clave"), reg.getInt("bloqueada"));
			}
			s.close();
			this.cerrar();
			return t;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar tarjeta");

		}
	}

	public int sacarDineroDebito(Tarjeta tarjetas, double dinero) {
		String cadena = "UPDATE cuentas set saldo = saldo - " + dinero + " WHERE número = " + tarjetas.getCuenta()
				+ " AND saldo >= 0";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadena);
			s.close();
			this.cerrar();
			return filas;

		} catch (SQLException e) {
			System.out.println("Error");
			this.cerrar();
			return -1;
		}
	}

	public Tarjeta buscarTarjetaCredito(int numTarjeta, String clave, double importe) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM tarjetas WHERE numero=" + numTarjeta + " AND clave ='" + clave
				+ "' AND limite > " + importe;
		Tarjeta t = null;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				t = new Tarjeta(reg.getInt("numero"), reg.getInt("cuenta"), reg.getString("titular"),
						reg.getDouble("limite"), reg.getString("tipo"), reg.getDate("caducidad").toLocalDate(),
						reg.getString("clave"), reg.getInt("bloqueada"));
			}
			s.close();
			this.cerrar();
			return t;
		} catch (SQLException e) {
			this.cerrar();
			throw new ErrorBaseDatos("Error al buscar tarjeta");

		}
	}

	public int sacarDineroCredito(Tarjeta tarjetas, double dinero) {
		String cadena = "UPDATE cuentas set saldo = saldo - " + dinero + " WHERE número = " + tarjetas.getCuenta();
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadena);
			s.close();
			this.cerrar();
			return filas;

		} catch (SQLException e) {
			System.out.println("Error");
			this.cerrar();
			return -1;
		}
	}

	public int altaMovimiento(Movimiento mov) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO movimientos VALUES(" + mov.getNumero() + "," + mov.getTarjeta() + ","
				+ mov.getCargado() + "," + mov.getImporte() + ",'" + mov.getFecha() +"')";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}

}
